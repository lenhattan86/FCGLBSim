function x = double( v ) %#ok
error( 'Disciplined convex programming error:\n   Constraints may not appear in if/then statements.', 1 ); %#ok

% Copyright 2005-2016 CVX Research, Inc. 
% See the file LICENSE.txt for full copyright information.
% The command 'cvx_where' will show where this file is located.
